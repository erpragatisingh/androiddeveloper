/**
 * Minimal HTTP client for Android wrapping {@link java.net.HttpURLConnection}.
 * 
 * Main class is {@link com.turbomanage.httpclient.android.AndroidHttpClient}.
 */
package com.turbomanage.httpclient.android;